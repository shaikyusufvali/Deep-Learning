DIGITS IMAGE CLASSIFICATION DATASET

1797 handwritten digit images
Image size: 8 x 8 pixels
64 pixel features per image
Classes: 0 to 9
Target column: label

Each CSV row represents one image:
pixel_0 ... pixel_63 = pixel values
label = actual digit class

Recommended ANN:
64 inputs -> 128 ReLU -> 64 ReLU -> 10 Softmax

Loss: Sparse Categorical Crossentropy
Metric: Accuracy
